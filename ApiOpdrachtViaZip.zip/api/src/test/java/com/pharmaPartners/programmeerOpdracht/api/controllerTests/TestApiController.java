package com.pharmaPartners.programmeerOpdracht.api.controllerTests;

import static org.junit.Assert.fail;

import org.junit.Test;

class TestApiController {

	@Test
	void test() {
		// Test create currency

		// test read currency (specific based on ID and all)

		// test update and read again

		// test delete
		fail("not implemented yet");
	}

}
